import { defineConfig, loadEnv } from 'vite';
import react from '@vitejs/plugin-react-swc';

export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, process.cwd(), '');
  const base =
    env.GITHUB_PAGES && env.REPO_NAME ? `/${env.REPO_NAME}/` : '/';
  return {
    base,
    plugins: [react()],
    build: {
      sourcemap: true,
      outDir: 'dist'
    },
    test: {
      environment: 'happy-dom',
      setupFiles: 'src/tests/setupTests.ts',
      css: true
    }
  };
});
