import { render, screen } from '@testing-library/react';
import { HashRouter } from 'react-router-dom';
import Home from '../pages/Home';

describe('Home page', () => {
  it('renders camera component', async () => {
    render(<HashRouter><Home /></HashRouter>);
    const cam = await screen.findByTestId('camera-card');
    expect(cam).toBeInTheDocument();
  });
});
