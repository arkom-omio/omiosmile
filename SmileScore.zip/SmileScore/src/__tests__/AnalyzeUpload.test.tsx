import { render, screen, fireEvent, act } from '@testing-library/react';
import { HashRouter, Route, Routes } from 'react-router-dom';
import Home from '../pages/Home';
import Analyze from '../pages/Analyze';
import { useAppStore } from '../store/useAppStore';

describe('Upload triggers analysis', () => {
  it('uploads and shows positive verdict', async () => {
    render(
      <HashRouter>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/analyze" element={<Analyze />} />
        </Routes>
      </HashRouter>
    );
    const input = await screen.findByTestId('file-input');
    const file = new File(['fake'], 'photo.jpg', { type: 'image/jpeg' });

    await act(async () => { fireEvent.change(input, { target: { files: [file] } }); });

    const img = useAppStore.getState().session.image;
    expect(img).toBeTruthy();

    await act(async () => { await useAppStore.getState().actions.analyze(img!); });

    const verdict = await screen.findByText(/Искренняя/);
    expect(verdict).toBeInTheDocument();
  });
});
