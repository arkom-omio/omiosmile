import { render, screen, fireEvent } from '@testing-library/react';
import { HashRouter } from 'react-router-dom';
import Gallery from '../pages/Gallery';
import { useAppStore } from '../store/useAppStore';

function seedHistory() {
  useAppStore.setState({
    history: [
      { id: '1', ts: Date.now(), image: 'data:,1', score: 70, verdict: 'Лучезарная ✨' },
      { id: '2', ts: Date.now(), image: 'data:,2', score: 40, verdict: 'Дружелюбная 😄' }
    ]
  } as any);
}

describe('Gallery', () => {
  it('lists history and allows delete', async () => {
    seedHistory();
    render(<HashRouter><Gallery /></HashRouter>);
    const cards = await screen.findAllByRole('img');
    expect(cards.length).toBeGreaterThanOrEqual(2);
    const delButtons = screen.getAllByRole('button', { name: /Удалить|Delete/ });
    fireEvent.click(delButtons[0]);
    const imgs = screen.getAllByRole('img');
    expect(imgs.length).toBeLessThan(cards.length);
  });
});
