import { render, screen, fireEvent } from '@testing-library/react';
import { HashRouter } from 'react-router-dom';
import Header from '../components/Header';
import { useAppStore } from '../store/useAppStore';

describe('Language toggle', () => {
  it('switches RU/EN', async () => {
    render(<HashRouter><Header /></HashRouter>);
    expect(screen.getByText('Главная')).toBeInTheDocument();
    const eng = screen.getByRole('button', { name: /Eng/ });
    fireEvent.click(eng);
    expect(screen.getByText('Home')).toBeInTheDocument();
    useAppStore.getState().actions.setLang('ru');
  });
});
