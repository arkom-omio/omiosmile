import { lazy } from 'react';
import { useRoutes } from 'react-router-dom';
import Skeleton from './components/Skeleton';

const Home = lazy(() => import('./pages/Home'));
const Analyze = lazy(() => import('./pages/Analyze'));
const Gallery = lazy(() => import('./pages/Gallery'));
const About = lazy(() => import('./pages/About'));
const Privacy = lazy(() => import('./pages/Privacy'));

export default function AppRoutes() {
  const elements = useRoutes([
    { path: '/', element: <Home /> },
    { path: '/analyze', element: <Analyze /> },
    { path: '/gallery', element: <Gallery /> },
    { path: '/about', element: <About /> },
    { path: '/privacy', element: <Privacy /> }
  ]);
  return elements ?? <Skeleton suspense />;
}
