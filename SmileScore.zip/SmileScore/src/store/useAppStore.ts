import { create } from 'zustand';
import { nanoid } from '../utils/nanoid';
import { analyzeDataUrl, verdictFromScore } from '../lib/smile';
import { loadHistory, saveHistory, loadSettings, saveSettings, type HistoryItem } from '../lib/storage';

type Theme = 'system' | 'light' | 'dark';
type Lang = 'ru' | 'en';

type State = {
  session: { image: string | null; };
  history: HistoryItem[];
  settings: { theme: Theme; lang: Lang; };
  actions: {
    setCurrentImage: (dataUrl: string | null) => void;
    analyze: (dataUrl: string) => Promise<void>;
    reanalyze: (dataUrl: string) => Promise<void>;
    removeHistory: (id: string) => void;
    setTheme: (t: Theme) => void;
    setLang: (l: Lang) => void;
  };
};

const persistedSettings = loadSettings<{ theme: Theme; lang: Lang }>({ theme: 'system', lang: 'ru' });

export const useAppStore = create<State>((set, get) => ({
  session: { image: null },
  history: loadHistory(),
  settings: persistedSettings,
  actions: {
    setCurrentImage: (image) => set((s) => ({ session: { image } })),
    analyze: async (dataUrl) => {
      const res = await analyzeDataUrl(dataUrl);
      const item: HistoryItem = { id: nanoid(), ts: Date.now(), image: dataUrl, score: res.score, verdict: res.verdict ?? verdictFromScore(res.score) };
      const hist = [item, ...get().history];
      saveHistory(hist);
      set({ history: hist });
      set({ session: { image: dataUrl } });
    },
    reanalyze: async (dataUrl) => { await get().actions.analyze(dataUrl); },
    removeHistory: (id) => set((s) => { const hist = s.history.filter((h) => h.id !== id); saveHistory(hist); return { history: hist }; }),
    setTheme: (theme) => set((s) => { const next = { ...s.settings, theme }; saveSettings(next); return { settings: next }; }),
    setLang: (lang) => set((s) => { const next = { ...s.settings, lang }; saveSettings(next); return { settings: next }; })
  }
}));
