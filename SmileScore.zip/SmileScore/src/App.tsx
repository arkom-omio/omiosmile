import { Outlet } from 'react-router-dom';
import Header from './components/Header';

export default function App() {
  return (
    <div className="min-h-full flex flex-col">
      <Header />
      <main className="container mx-auto max-w-6xl px-4 sm:px-6 lg:px-8 py-8 flex-1">
        <Outlet />
      </main>
      <footer className="px-6 py-8 text-sm text-neutral-500 text-center">
        <p>
          © {new Date().getFullYear()} SmileScore · <a href="#/privacy">Privacy</a> · <a href="#/about">About</a>
        </p>
      </footer>
    </div>
  );
}
