import '@testing-library/jest-dom';

Object.defineProperty(global.navigator, 'mediaDevices', {
  value: { getUserMedia: vi.fn().mockResolvedValue({ getTracks: () => [{ stop: () => {} }] }) },
  configurable: true
});
Object.defineProperty(global.HTMLMediaElement.prototype, 'play', { value: vi.fn().mockResolvedValue(undefined) });

vi.mock('../lib/smile', async () => {
  const actual = await vi.importActual<any>('../lib/smile');
  return { ...actual, analyzeDataUrl: vi.fn().mockResolvedValue({ score: 88, verdict: 'Искренняя 🌟', metrics: { lift: 0.8, mar: 0.7, teeth: 0.6 } }) };
});
