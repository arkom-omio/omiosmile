import { en } from './en';
import { ru } from './ru';
import { useAppStore } from '../store/useAppStore';

export type Locale = 'ru' | 'en';
export const dict = { en, ru };

export function t<K extends keyof typeof en>(key: K): (typeof en)[K] {
  const lang = useAppStore.getState().settings.lang;
  return (dict[lang] as any)[key];
}

export function tt(path: string, fallback = ''): string {
  const lang = useAppStore.getState().settings.lang;
  const parts = path.split('.');
  let cur: any = dict[lang];
  for (const p of parts) cur = cur?.[p];
  return typeof cur === 'string' ? cur : fallback;
}
