export const en = {
  appName: 'SmileScore',
  tagline: 'Minimal smile analysis — privately in your browser',
  nav: { home: 'Home', gallery: 'Gallery', about: 'About', privacy: 'Privacy' },
  home: {
    title: 'Capture or upload a photo',
    cameraUnavailable: 'Camera unavailable. Try upload instead.',
    tipsTitle: 'Friendly tips',
    tips: ['Good light in front of you','Face centered in frame','Relax your face and smile 🙂'],
    capture: 'Capture',
    analyzing: 'Analyzing...',
    uploadCta: 'Upload image',
    or: 'or'
  },
  analyze: {
    title: 'Your smile', score: 'Smile score', verdictTitle: 'Verdict',
    again: 'Try again', save: 'Save to history', export: 'Download photo', share: 'Share', copied: 'Copied!', reanalyze: 'Re-analyze'
  },
  gallery: { title: 'History', empty: 'No entries yet. Your smiles will appear here.', compare: 'Compare', delete: 'Delete', reanalyze: 'Re-analyze' },
  about: { title: 'How it works', body: 'SmileScore detects facial landmarks locally using MediaPipe Face Landmarker and computes a smile score from mouth geometry. This is for fun and content creation — not a medical tool.' },
  privacy: { title: 'Privacy', body: 'Processing happens locally in your browser. Photos never leave your device. Models are loaded as static files from this site only, and no images are sent to any server.' },
  verdicts: { warm: 'Warm 🙂', friendly: 'Friendly 😄', radiant: 'Radiant ✨', sincere: 'Sincere 🌟', noFace: 'We could not clearly see a face — try better light and face centered.' },
  theme: { auto: 'Auto', light: 'Light', dark: 'Dark' },
  lang: { label: 'Language', ru: 'Рус', en: 'Eng' }
};
