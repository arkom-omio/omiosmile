import {
  FaceLandmarker,
  FilesetResolver,
  type FaceLandmarkerResult
} from '@mediapipe/tasks-vision';
import { tt } from '../i18n/i18n';

let landmarker: FaceLandmarker | null = null;
let loading: Promise<void> | null = null;

async function ensureModel() {
  if (landmarker) return;
  if (loading) return loading;
  loading = (async () => {
    const fileset = await FilesetResolver.forVisionTasks('/models');
    landmarker = await FaceLandmarker.createFromOptions(fileset, {
      baseOptions: { modelAssetPath: '/models/face_landmarker.task' },
      numFaces: 1, outputFaceBlendshapes: false, runningMode: 'IMAGE'
    });
  })();
  return loading;
}

type Metrics = { lift: number; mar: number; teeth: number; };
export type SmileAnalysis = { score: number; verdict: string; metrics: Metrics; landmarks?: { x: number; y: number }[]; };

function dist(a: any, b: any) { const dx = a.x - b.x; const dy = a.y - b.y; return Math.hypot(dx, dy); }
function clamp01(n: number) { return Math.max(0, Math.min(1, n)); }

function estimateTeethBrightness(canvas: HTMLCanvasElement, mouthCx: number, mouthCy: number, mouthW: number) {
  const ctx = canvas.getContext('2d')!;
  const r = Math.max(4, Math.floor((mouthW * canvas.width) / 2));
  const x = Math.floor(mouthCx * canvas.width - r / 2);
  const y = Math.floor(mouthCy * canvas.height - r / 2);
  const w = Math.max(2, Math.floor(r));
  const h = Math.max(2, Math.floor(r * 0.6));
  const img = ctx.getImageData(Math.max(0, x), Math.max(0, y), Math.min(canvas.width - x, w), Math.min(canvas.height - y, h));
  let sum = 0;
  for (let i = 0; i < img.data.length; i += 4) {
    const R = img.data[i], G = img.data[i+1], B = img.data[i+2];
    const yLum = 0.2126 * R + 0.7152 * G + 0.0722 * B;
    sum += yLum;
  }
  const avg = sum / (img.data.length / 4) / 255;
  return clamp01((avg - 0.35) / 0.4);
}

function computeMetrics(landmarks: any[], canvas: HTMLCanvasElement): Metrics {
  const L = landmarks[61], R = landmarks[291], U = landmarks[13], D = landmarks[14];
  const mouthW = dist(L, R);
  const mar = clamp01((dist(U, D) / mouthW - 0.2) / 0.5);
  const centerY = (U.y + D.y) / 2;
  const liftL = (centerY - L.y) / mouthW;
  const liftR = (centerY - R.y) / mouthW;
  const lift = clamp01((((liftL + liftR) / 2) - 0.02) / 0.2);
  const mouthCx = (L.x + R.x) / 2; const mouthCy = centerY;
  const teeth = estimateTeethBrightness(canvas, mouthCx, mouthCy, mouthW);
  return { lift, mar, teeth };
}

function combineScore(m: Metrics) {
  const s = 0.5 * m.lift + 0.3 * m.mar + 0.2 * m.teeth;
  const sigmoid = (x: number) => 1 / (1 + Math.exp(-4 * (x - 0.5)));
  return Math.round(clamp01(sigmoid(s)) * 100);
}

export function verdictFromScore(score: number): string {
  if (score <= 25) return tt('verdicts.warm');
  if (score <= 50) return tt('verdicts.friendly');
  if (score <= 75) return tt('verdicts.radiant');
  return tt('verdicts.sincere');
}

export async function analyzeDataUrl(dataUrl: string) {
  await ensureModel();
  const img = await new Promise<HTMLImageElement>((resolve, reject) => {
    const im = new Image(); im.onload = () => resolve(im); im.onerror = reject; im.src = dataUrl;
  });
  const canvas = document.createElement('canvas'); canvas.width = img.width; canvas.height = img.height;
  const ctx = canvas.getContext('2d')!; ctx.drawImage(img, 0, 0);

  if (!landmarker) throw new Error('Landmarker not ready');
  const res: FaceLandmarkerResult = (landmarker as any).detect(img);
  const lm = (res as any)?.faceLandmarks?.[0];
  if (!lm) {
    return { score: 40, verdict: tt('verdicts.noFace'), metrics: { lift: 0.2, mar: 0.2, teeth: 0.2 } };
  }
  const metrics = computeMetrics(lm as any, canvas);
  const score = combineScore(metrics);
  const verdict = verdictFromScore(score);
  return { score, verdict, metrics, landmarks: (lm as any).map((p: any) => ({ x: p.x, y: p.y })) };
}
