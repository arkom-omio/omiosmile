export type HistoryItem = { id: string; ts: number; image: string; score: number; verdict: string; };
const KEY = 'smilescore.history'; const SETTINGS_KEY = 'smilescore.settings';

export function loadHistory(): HistoryItem[] {
  try { const raw = localStorage.getItem(KEY); return raw ? (JSON.parse(raw) as HistoryItem[]) : []; } catch { return []; }
}
export function saveHistory(items: HistoryItem[]) { localStorage.setItem(KEY, JSON.stringify(items.slice(0, 100))); }
export function loadSettings<T>(fallback: T): T {
  try { const raw = localStorage.getItem(SETTINGS_KEY); return raw ? (JSON.parse(raw) as T) : fallback; } catch { return fallback; }
}
export function saveSettings<T>(settings: T) { localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings)); }
