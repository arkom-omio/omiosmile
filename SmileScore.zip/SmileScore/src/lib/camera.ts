export async function startCamera(): Promise<MediaStream> {
  if (!navigator.mediaDevices?.getUserMedia) throw new Error('getUserMedia not supported');
  return navigator.mediaDevices.getUserMedia({
    video: { facingMode: 'user', width: { ideal: 1280 }, height: { ideal: 720 } },
    audio: false
  });
}
export function stopStream(stream: MediaStream | null) { stream?.getTracks().forEach((t) => t.stop()); }
