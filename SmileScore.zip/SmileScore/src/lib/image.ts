export async function dataUrlToImage(dataUrl: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = reject;
    img.src = dataUrl;
  });
}
export function toCanvas(el: HTMLImageElement | HTMLVideoElement | ImageBitmap) {
  const w = (el as any).videoWidth ?? (el as any).width;
  const h = (el as any).videoHeight ?? (el as any).height;
  const canvas = document.createElement('canvas');
  canvas.width = w; canvas.height = h;
  const ctx = canvas.getContext('2d')!;
  ctx.drawImage(el as any, 0, 0);
  return canvas;
}
export function resizeDataUrl(dataUrl: string, maxW = 1024, maxH = 1024): string {
  const img = document.createElement('img'); img.src = dataUrl;
  const canvas = document.createElement('canvas');
  return new Promise<string>((resolve) => {
    img.onload = () => {
      let { width, height } = img as any;
      const ratio = Math.min(maxW / width, maxH / height, 1);
      width = Math.round(width * ratio); height = Math.round(height * ratio);
      canvas.width = width; canvas.height = height;
      const ctx = canvas.getContext('2d')!;
      ctx.drawImage(img, 0, 0, width, height);
      resolve(canvas.toDataURL('image/jpeg', 0.9));
    };
  }) as unknown as string;
}
