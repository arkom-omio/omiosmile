import { Suspense } from 'react';
import CameraCard from '../components/CameraCard';
import UploadDropzone from '../components/UploadDropzone';
import { useNavigate } from 'react-router-dom';
import { useAppStore } from '../store/useAppStore';
import Skeleton from '../components/Skeleton';

export default function Home() {
  const nav = useNavigate();
  const setCurrentImage = useAppStore((s) => s.actions.setCurrentImage);

  const handleSelect = (dataUrl: string) => {
    setCurrentImage(dataUrl);
    nav('/analyze');
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      <Suspense fallback={<Skeleton />}>
        <CameraCard onCapture={handleSelect} />
      </Suspense>
      <UploadDropzone onSelect={handleSelect} />
    </div>
  );
}
