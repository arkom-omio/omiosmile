import { tt } from '../i18n/i18n';

export default function About() {
  return (
    <article className="prose dark:prose-invert max-w-none">
      <h1>{tt('about.title')}</h1>
      <p>{tt('about.body')}</p>
      <h2>Algorithm (overview)</h2>
      <ol>
        <li>Detect face landmarks locally (MediaPipe Face Landmarker).</li>
        <li>Compute mouth geometry — corner lift, mouth aspect ratio, teeth brightness proxy.</li>
        <li>Normalize by mouth width, combine with weights → score 0–100.</li>
        <li>Map to friendly verdicts only — no negative labels.</li>
      </ol>
      <p>SmileScore is designed for creators and everyday users to choose avatars and compare “before/after”. It is not a diagnostic tool.</p>
    </article>
  );
}
