import { Trash2, Repeat } from 'lucide-react';
import { useAppStore } from '../store/useAppStore';
import EmptyState from '../components/EmptyState';
import { useNavigate } from 'react-router-dom';
import { tt } from '../i18n/i18n';

export default function Gallery() {
  const nav = useNavigate();
  const items = useAppStore((s) => s.history);
  const remove = useAppStore((s) => s.actions.removeHistory);
  const reanalyze = useAppStore((s) => s.actions.reanalyze);

  if (items.length === 0) return <EmptyState text={tt('gallery.empty')} />;

  return (
    <div>
      <h2 className="text-2xl font-semibold mb-4">{tt('gallery.title')}</h2>
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {items.map((it) => (
          <div key={it.id} className="card overflow-hidden">
            <img src={it.image} alt={String(it.score)} className="w-full" />
            <div className="p-4 flex items-center justify-between">
              <div className="text-sm">
                <div className="font-semibold">{it.verdict}</div>
                <div className="opacity-70">Score {Math.round(it.score)}</div>
              </div>
              <div className="flex gap-2">
                <button className="btn" onClick={() => reanalyze(it.image).then(() => nav('/analyze'))}>
                  <Repeat className="w-4 h-4" /> {tt('gallery.reanalyze')}
                </button>
                <button className="btn" onClick={() => remove(it.id)} aria-label={tt('gallery.delete')}>
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
