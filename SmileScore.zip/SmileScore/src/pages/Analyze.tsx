import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import ResultCard from '../components/ResultCard';
import { useAppStore } from '../store/useAppStore';
import ScoreBadge from '../components/ScoreBadge';
import { tt } from '../i18n/i18n';

export default function Analyze() {
  const nav = useNavigate();
  const image = useAppStore((s) => s.session.image);
  const analyze = useAppStore((s) => s.actions.analyze);
  const [loading, setLoading] = useState(false);
  const last = useAppStore((s) => (s.history.length ? s.history[0] : null));

  useEffect(() => {
    (async () => {
      if (!image) { nav('/'); return; }
      setLoading(true);
      await analyze(image);
      setLoading(false);
    })();
  }, [image, analyze, nav]);

  if (!image) return null;

  return (
    <div className="space-y-6">
      {loading && (
        <div className="card p-6 flex items-center justify-between">
          <div className="font-semibold">{tt('home.analyzing')}</div>
          <ScoreBadge score={42} verdict={tt('verdicts.warm')} />
        </div>
      )}
      {last && !loading && <ResultCard image={last.image} score={last.score} verdict={last.verdict} />}
      <div className="flex gap-2">
        <button className="btn" onClick={() => nav('/')}>{tt('analyze.again')}</button>
        <button className="btn" onClick={() => nav('/gallery')}>{tt('nav.gallery')}</button>
      </div>
    </div>
  );
}
