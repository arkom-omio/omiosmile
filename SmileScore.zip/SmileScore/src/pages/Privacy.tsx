import { tt } from '../i18n/i18n';

export default function Privacy() {
  return (
    <article className="prose dark:prose-invert max-w-none">
      <h1>{tt('privacy.title')}</h1>
      <p>{tt('privacy.body')}</p>
      <ul>
        <li>No servers. Images are never uploaded anywhere.</li>
        <li>History and settings are stored in your browser (localStorage).</li>
        <li>GitHub Pages hosting; routing via <code>#/</code> for compatibility.</li>
      </ul>
    </article>
  );
}
