import { Moon, Sun, MonitorCog } from 'lucide-react';
import { useAppStore } from '../store/useAppStore';
import { tt } from '../i18n/i18n';

export default function ThemeToggle() {
  const theme = useAppStore((s) => s.settings.theme);
  const setTheme = useAppStore((s) => s.actions.setTheme);

  return (
    <div className="flex items-center gap-2" role="group" aria-label="Theme">
      <button className={\`btn \${theme === 'system' ? 'btn-primary' : ''}\`} onClick={() => setTheme('system')} aria-pressed={theme === 'system'} title={tt('theme.auto')}>
        <MonitorCog className="w-4 h-4" />
      </button>
      <button className={\`btn \${theme === 'light' ? 'btn-primary' : ''}\`} onClick={() => setTheme('light')} aria-pressed={theme === 'light'} title={tt('theme.light')}>
        <Sun className="w-4 h-4" />
      </button>
      <button className={\`btn \${theme === 'dark' ? 'btn-primary' : ''}\`} onClick={() => setTheme('dark')} aria-pressed={theme === 'dark'} title={tt('theme.dark')}>
        <Moon className="w-4 h-4" />
      </button>
    </div>
  );
}
