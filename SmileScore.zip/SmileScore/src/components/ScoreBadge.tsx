type Props = { score: number; verdict: string; };

export default function ScoreBadge({ score, verdict }: Props) {
  return (
    <div className="inline-flex items-center gap-3 px-5 py-3 rounded-full border border-neutral-300 dark:border-neutral-700 bg-white/70 dark:bg-neutral-900/70 backdrop-blur" aria-live="polite">
      <span className="text-xl font-bold tabular-nums">{Math.round(score)}</span>
      <span className="text-neutral-600 dark:text-neutral-300">{verdict}</span>
    </div>
  );
}
