import { ImageOff } from 'lucide-react';

export default function EmptyState({ text }: { text: string }) {
  return (
    <div className="card p-8 text-center">
      <div className="flex flex-col items-center gap-3">
        <ImageOff className="w-10 h-10" />
        <p className="text-neutral-600 dark:text-neutral-300">{text}</p>
      </div>
    </div>
  );
}
