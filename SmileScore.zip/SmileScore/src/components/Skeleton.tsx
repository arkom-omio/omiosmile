type Props = { suspense?: boolean };
export default function Skeleton({ suspense }: Props) {
  if (suspense) return <div className="p-6 text-neutral-500">...</div>;
  return (
    <div className="animate-pulse p-6">
      <div className="h-6 bg-neutral-200 dark:bg-neutral-800 rounded w-40 mb-4" />
      <div className="h-48 bg-neutral-200 dark:bg-neutral-800 rounded" />
    </div>
  );
}
