import { useRef, useState } from 'react';
import { Upload } from 'lucide-react';
import { tt } from '../i18n/i18n';

type Props = { onSelect: (dataUrl: string) => void; };

export default function UploadDropzone({ onSelect }: Props) {
  const inputRef = useRef<HTMLInputElement | null>(null);
  const [drag, setDrag] = useState(false);

  const open = () => inputRef.current?.click();

  const handleFiles = (files: FileList | null) => {
    const file = files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => { onSelect(String(reader.result)); };
    reader.readAsDataURL(file);
  };

  return (
    <section
      className={\`card p-6 text-center \${drag ? 'ring-2 ring-neutral-500' : ''}\`}
      onDragOver={(e) => { e.preventDefault(); setDrag(true); }}
      onDragLeave={() => setDrag(false)}
      onDrop={(e) => { e.preventDefault(); setDrag(false); handleFiles(e.dataTransfer.files); }}
      aria-label="Upload"
    >
      <input ref={inputRef} type="file" accept="image/*" className="hidden"
        onChange={(e) => handleFiles(e.target.files)} data-testid="file-input" />
      <div className="flex flex-col items-center gap-3">
        <Upload className="w-8 h-8" />
        <p className="text-neutral-600 dark:text-neutral-400">{tt('home.or')}</p>
        <button className="btn btn-primary" onClick={open}>{tt('home.uploadCta')}</button>
      </div>
    </section>
  );
}
