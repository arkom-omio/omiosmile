import { useEffect, useRef, useState } from 'react';
import { Camera, CameraOff } from 'lucide-react';
import { startCamera, stopStream } from '../lib/camera';
import { tt } from '../i18n/i18n';

type Props = { onCapture: (dataUrl: string) => void; };

export default function CameraCard({ onCapture }: Props) {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    let active = true;
    (async () => {
      try {
        setError(null);
        const stream = await startCamera();
        if (!active) return;
        if (videoRef.current) {
          (videoRef.current as any).srcObject = stream;
          await (videoRef.current as any).play();
          setReady(true);
        }
      } catch (_e) {
        setError(tt('home.cameraUnavailable'));
      }
    })();
    return () => {
      active = false;
      const vid = videoRef.current;
      if (vid && (vid as any).srcObject) stopStream((vid as any).srcObject as MediaStream);
    };
  }, []);

  const handleCapture = () => {
    const video = videoRef.current!;
    const canvas = document.createElement('canvas');
    canvas.width = (video as any).videoWidth;
    canvas.height = (video as any).videoHeight;
    const ctx = canvas.getContext('2d')!;
    ctx.drawImage(video, 0, 0);
    const url = canvas.toDataURL('image/jpeg', 0.9);
    onCapture(url);
  };

  return (
    <section className="card p-4" aria-label="Camera" data-testid="camera-card">
      <div className="flex items-center justify-between mb-3">
        <div className="font-semibold">{tt('home.title')}</div>
        <div className="text-neutral-500 text-sm">{ready ? 'HD' : '...'}</div>
      </div>
      <div className="relative aspect-video rounded-2xl overflow-hidden bg-neutral-100 dark:bg-neutral-800">
        {error ? (
          <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 p-6 text-center">
            <CameraOff className="w-8 h-8" />
            <p>{error}</p>
            <ul className="text-sm opacity-80">
              {tt('home.tips').map((s, i) => (<li key={i}>• {s}</li>))}
            </ul>
          </div>
        ) : (
          <video ref={videoRef} muted playsInline className="w-full h-full object-cover" aria-label="Live camera" />
        )}
      </div>
      <div className="mt-4">
        <button className="btn btn-primary" onClick={handleCapture} disabled={!ready}>
          <Camera className="w-4 h-4" /> {tt('home.capture')}
        </button>
      </div>
    </section>
  );
}
