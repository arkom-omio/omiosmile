import { useState } from 'react';
import ScoreBadge from './ScoreBadge';
import { Download, Share2 } from 'lucide-react';
import { tt } from '../i18n/i18n';

type Props = { image: string; score: number; verdict: string; };

export default function ResultCard({ image, score, verdict }: Props) {
  const [copied, setCopied] = useState(false);

  const download = () => {
    const a = document.createElement('a');
    a.href = image;
    a.download = \`smilescore-\${Math.round(score)}.jpg\`;
    a.click();
  };

  const share = async () => {
    if (navigator.share) {
      try {
        await navigator.share({ title: 'SmileScore', text: \`My smile is \${Math.round(score)} — \${verdict}\`, url: location.href });
      } catch { /* noop */ }
    } else {
      await navigator.clipboard.writeText(location.href);
      setCopied(true);
      setTimeout(() => setCopied(false), 1200);
    }
  };

  return (
    <section className="card p-4">
      <div className="flex items-center justify-between mb-3">
        <h3 className="font-semibold">{tt('analyze.title')}</h3>
        <ScoreBadge score={score} verdict={verdict} />
      </div>
      <div className="rounded-2xl overflow-hidden bg-neutral-100 dark:bg-neutral-800">
        <img src={image} alt="Result" className="w-full" />
      </div>
      <div className="mt-4 flex flex-wrap gap-2">
        <button className="btn btn-primary" onClick={download}><Download className="w-4 h-4" /> {tt('analyze.export')}</button>
        <button className="btn" onClick={share}><Share2 className="w-4 h-4" /> {copied ? tt('analyze.copied') : tt('analyze.share')}</button>
      </div>
    </section>
  );
}
