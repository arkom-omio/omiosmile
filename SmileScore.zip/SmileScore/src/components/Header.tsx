import { Link, useLocation } from 'react-router-dom';
import ThemeToggle from './ThemeToggle';
import { useAppStore } from '../store/useAppStore';
import { Languages } from 'lucide-react';
import { tt } from '../i18n/i18n';

function LangSwitcher() {
  const lang = useAppStore((s) => s.settings.lang);
  const setLang = useAppStore((s) => s.actions.setLang);
  return (
    <div className="flex items-center gap-2" aria-label={tt('lang.label')}>
      <Languages className="w-4 h-4" />
      <button className={\`btn \${lang === 'ru' ? 'btn-primary' : ''}\`} onClick={() => setLang('ru')} aria-pressed={lang === 'ru'}>
        {tt('lang.ru')}
      </button>
      <button className={\`btn \${lang === 'en' ? 'btn-primary' : ''}\`} onClick={() => setLang('en')} aria-pressed={lang === 'en'}>
        {tt('lang.en')}
      </button>
    </div>
  );
}

export default function Header() {
  const loc = useLocation();
  return (
    <header className="sticky top-0 z-10 backdrop-blur border-b border-neutral-200/60 dark:border-neutral-800/60">
      <div className="container mx-auto max-w-6xl px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between">
        <Link to="/" className="flex items-center gap-3 no-underline">
          <img src="/favicon.svg" alt="SmileScore" className="w-8 h-8 rounded-xl" />
          <div className="leading-tight">
            <div className="font-semibold text-lg">SmileScore</div>
            <div className="text-xs text-neutral-500">{tt('tagline')}</div>
          </div>
        </Link>

        <nav className="hidden md:flex items-center gap-2">
          <Link className={\`btn \${loc.pathname === '/' ? 'btn-primary' : ''}\`} to="/">{tt('nav.home')}</Link>
          <Link className={\`btn \${loc.pathname === '/gallery' ? 'btn-primary' : ''}\`} to="/gallery">{tt('nav.gallery')}</Link>
          <Link className={\`btn \${loc.pathname === '/about' ? 'btn-primary' : ''}\`} to="/about">{tt('nav.about')}</Link>
          <Link className={\`btn \${loc.pathname === '/privacy' ? 'btn-primary' : ''}\`} to="/privacy">{tt('nav.privacy')}</Link>
        </nav>

        <div className="flex items-center gap-3">
          <LangSwitcher />
          <ThemeToggle />
        </div>
      </div>
    </header>
  );
}
