// See README: downloads mediapipe model/statics into public/models
import fs from 'node:fs';
import path from 'node:path';
import https from 'node:https';

const files = [
  {
    url: 'https://storage.googleapis.com/mediapipe-models/face_landmarker/face_landmarker/float16/latest/face_landmarker.task',
    out: 'public/models/face_landmarker.task'
  },
  { url: 'https://storage.googleapis.com/mediapipe-tasks/web/wasm/vision_wasm_internal.wasm', out: 'public/models/vision_wasm_internal.wasm' },
  { url: 'https://storage.googleapis.com/mediapipe-tasks/web/wasm/vision_wasm_internal.simd.wasm', out: 'public/models/vision_wasm_internal.simd.wasm' },
  { url: 'https://storage.googleapis.com/mediapipe-tasks/web/wasm/vision_bundle.js', out: 'public/models/vision_bundle.js' }
];

function download(url, out) {
  return new Promise((resolve, reject) => {
    const dir = path.dirname(out);
    fs.mkdirSync(dir, { recursive: true });
    const file = fs.createWriteStream(out);
    https.get(url, (res) => {
      if (res.statusCode !== 200) {
        reject(new Error(`HTTP ${res.statusCode} for ${url}`));
        return;
      }
      res.pipe(file);
      file.on('finish', () => file.close(resolve));
    }).on('error', (err) => {
      fs.unlink(out, () => reject(err));
    });
  });
}

(async () => {
  for (const f of files) {
    if (fs.existsSync(f.out)) { console.log(`✓ ${f.out} exists`); continue; }
    console.log(`↓ Download ${f.url}`);
    await download(f.url, f.out);
    console.log(`✓ Saved ${f.out}`);
  }
  console.log('Done.');
})().catch((e) => { console.error('Model fetch failed:', e); process.exit(1); });
