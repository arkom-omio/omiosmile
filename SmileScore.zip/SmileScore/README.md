# SmileScore

**Минималистичное веб‑приложение анализа улыбки — локально, в браузере.**

- Съёмка с камеры (`getUserMedia`) и загрузка изображения
- Локальный анализ улыбки (MediaPipe Face Landmarker) — **без отправки фото на сервер**
- Оценка 0–100 и позитивный вердикт
- История (localStorage), сравнение, экспорт, шаринг
- I18N: ru/en; тёмная/светлая тема (авто)
- HashRouter — совместимость с GitHub Pages

## Быстрый старт

```bash
npm ci
npm run fetch-models   # скачает statics моделей в public/models
npm run dev
```

Откройте `http://localhost:5173`.

## Скрипты

- `npm run dev` — локальный запуск (Vite)
- `npm run build` — сборка в `dist/`
- `npm run preview` — предпросмотр сборки
- `npm run test` — тесты (Vitest + Testing Library)
- `npm run lint` — ESLint
- `npm run format` — Prettier
- `npm run fetch-models` — скачивание файлов моделей MediaPipe в `public/models`

## Как это работает (алгоритм)

Используем **MediaPipe Face Landmarker** (WebAssembly) локально. Находим точки рта: 61 (левый угол), 291 (правый), 13 (верх губы), 14 (низ).

1. Нормализация по ширине рта `|L-R|`.
2. Подъём углов: среднее `((baselineY - y(L)) + (baselineY - y(R))) / 2 / width`, где baseline — середина между 13 и 14.
3. MAR: `|U-D| / |L-R|`.
4. Proxy видимости зубов: яркость центральной области рта на canvas.

Веса: 0.5 / 0.3 / 0.2 → сглаживание сигмоидой → **score 0–100**.

Маппинг в позитивные вердикты:

- 0–25 → «Тёплая 🙂»
- 26–50 → «Дружелюбная 😄»
- 51–75 → «Лучезарная ✨»
- 76–100 → «Искренняя 🌟»

Если лицо не найдено — дружелюбные подсказки, без негативной лексики.

## Приватность

- Обработка полностью локальная; фото не покидают устройство.
- Модели загружаются как статические файлы из `public/models`.

## Доступность

- ARIA, видимые focus‑rings; навигация с клавиатуры; контраст WCAG 2.1 AA.

## Производительность/SEO

- Vite + React.lazy, OG‑мета, цель Lighthouse ≥ 90.

## Деплой на GitHub Pages

1. Публичный репозиторий, ветка `main`.
2. Первый push → вкладка **Actions** → ждём успешный workflow.
3. **Settings → Pages**: Source = **GitHub Actions**.
4. Доступно по `https://<user>.github.io/<repo>/` (маршруты `/#/...`).

CI/CD: `.github/workflows/pages.yml` (checkout → setup‑node LTS → `npm ci` → `npm run fetch-models` → `npm run build` → upload artifact → `actions/deploy-pages@v4`).

## Критерии приёмки

- Сборка без ошибок; тесты зелёные.
- На `/privacy` явно указана локальная обработка.
- Позитивные формулировки во всех состояниях.
- Деплой на GitHub Pages проходит; навигация через `/#/...`.

## Лицензия

MIT — см. `LICENSE`.
